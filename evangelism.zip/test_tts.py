from tts import synthesize_speech

# Test using Mark's voice
synthesize_speech("This is a test of the emergency gospel system.", "1SM7GgM6IMuvQlz2BwM3")

